const apiHost = 'https://banegg.herokuapp.com';//'http://localhost:3001'
chrome.storage.sync.get("camps", ({ camps }) => {
  if (!camps) {
    fetch(`${apiHost}/campaignsUrl`)
    .then((res) => res.json())
    .then((camps) => {
      chrome.storage.sync.set({ camps });
    });
  }
});
chrome.storage.sync.get("color", ({ color }) => {
  // let changeColor = document.getElementById("changeColor");
  let hideBtn = document.getElementById("hide");
  
  
  // changeColor.style.backgroundColor = color;

  // changeColor.addEventListener("click", async () => {
  //   let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  //   chrome.scripting.executeScript({
  //     target: { tabId: tab.id },
  //     function: setPageBackgroundColor,
  //   });
  // });

  /******** Duplicated  ********/
  hideBtn &&
    hideBtn.addEventListener("click", function (e) {
      const address = document.getElementById("address").value;
      const url = document.getElementById("url").value;
      const hash = document.getElementById("hash").value;
      const prizepool = document.getElementById("prizepool").value;

      chrome.storage.sync.set({ address }); //store users wallet

      fetch(`${apiHost}/hide`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          address: address,
          url: url,
          hash: hash,
          prizepool: prizepool,
          claim_amnt: 1,
        }),
      })
        .then((res) => res.json())
        .then((res) => {
          console.log(res);
          const img = document.createElement("img");
          img.setAttribute("src", res.qr);
          document.getElementById("qrCode").append(img);
          fetch(`${apiHost}/check-campaign-payment`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              wallet: address,
              paymentAmount: res.amountRaw,
              id: res.id,
            }),
          })
            .then((res) => res.json())
            .then((res) => {
              //delete qr
              console.log(img);
              img && img.remove();
            });
        });

      const renderedEvt = new Event("rendered");
      hideBtn.dispatchEvent(renderedEvt);
    });
  /******** EOF: Duplicated  ********/

  document.getElementById("settings").addEventListener("click", function (e) {
    fetch("./fragments/settings.html")
      .then((res) => res.text())
      .then((fragmentString) => {
        const settings = document.createElement("div");
        settings.classList.add("settings");
        settings.innerHTML = fragmentString;
        // document.getElementsByTagName("section")[0].innerHTML = "";
        document.getElementsByTagName("section")[0].replaceChildren(settings);
        chrome.storage.sync.get("address", ({ address }) => {
          if (address) {
            document.getElementById("address").value = address;
          }
        });
        const settingsRendered = new Event("settings-rendered");
        document.dispatchEvent(settingsRendered);
      });
  });

  document.getElementById("home").addEventListener("click", function (e) {
    fetch("./fragments/about.html")
      .then((res) => res.text())
      .then((fragmentString) => {
        const home = document.createElement("div");
        home.classList.add("home");
        home.innerHTML = fragmentString;
        document.getElementsByTagName("section")[0].replaceChildren(home);
      })
      .finally(() => {
        const aboutRendered = new Event("rendered");
        document.dispatchEvent(aboutRendered);
      });
  });

  document.addEventListener("rendered", function (e) {
    document
      .getElementById("hide-ban-egg")
      .addEventListener("click", function (e) {
        fetch("/fragments/campaign.html")
          .then((res) => res.text())
          .then((string) => {
            const address = chrome.storage.sync.get(
              "address",
              ({ address }) => {
                if (address) {
                  document.getElementById("address").value = address;
                }
              }
            );
            const div = document.createElement("div");
            div.innerHTML = string;
            document.getElementsByTagName("section")[0].replaceChildren(div);
            /******** Hide button listener *********/
            document
              .getElementById("hide")
              .addEventListener("click", function (e) {
                const address = document.getElementById("address").value;
                const url = document.getElementById("url").value;
                const hash = document.getElementById("hash").value;
                const prizepool = document.getElementById("prizepool").value;

                chrome.storage.sync.set({ address }); //store users wallet

                fetch(`${apiHost}/hide`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                  },
                  body: JSON.stringify({
                    address: address,
                    url: url,
                    hash: hash,
                    prizepool: prizepool,
                    claim_amnt: 1,
                  }),
                })
                  .then((res) => res.json())
                  .then((res) => {
                    console.log(res);
                    const img = document.createElement("img");
                    img.setAttribute("src", res.qr);
                    document.getElementById("qrCode").append(img);
                    fetch(`${apiHost}/check-campaign-payment`, {
                      method: "POST",
                      headers: {
                        "Content-Type": "application/json",
                      },
                      body: JSON.stringify({
                        wallet: address,
                        paymentAmount: res.amountRaw,
                        id: res.id,
                      }),
                    })
                      .then((res) => res.json())
                      .then((res) => {
                        //delete qr
                        console.log(img);
                        img && img.remove();
                      });
                  });

                const renderedEvt = new Event("rendered");
                hideBtn.dispatchEvent(renderedEvt);
              });
          });
      });
  });

  document.addEventListener("settings-rendered", function (e) {
    document
      .getElementById("save-settings")
      .addEventListener("click", function (e) {
        const address = document.getElementById("address").value;
        chrome.storage.sync.set({ address });
        const messageStrip = document.createElement("p");
        messageStrip.innerText = "Settings saved";
        document.getElementsByTagName("section").append(p);
      });
  });

  fetch("/fragments/about.html")
    .then((res) => res.text())
    .then((string) => {
      const div = document.createElement("div");
      div.innerHTML = string;
      document.getElementsByTagName("section")[0].append(div);
    })
    .finally(function (e) {
      const aboutRendered = new Event("rendered");
      document.dispatchEvent(aboutRendered);
    });

  // The body of this function will be executed as a content script inside the
  // current page
  function setPageBackgroundColor() {
    chrome.storage.sync.get("color", ({ color }) => {
      document.body.style.backgroundColor = color;
    });
  }
});
